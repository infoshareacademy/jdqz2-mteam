import javax.json.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.SQLOutput;
import java.util.Scanner;

public class DataGeneratorApp {
    public static void main(String[] args) throws FileNotFoundException {
//        User user1 = new User(
//                new Name("Jakub", "Marchwicki"),
//                new Address("Poland", "Pomorskie"),
//                "kuba@gmail.com",
//                "kuba123"
//        );

//        Scanner howManyEntriesScanner = new Scanner(System.in);
//        System.out.print("Enter number of users to generate: ");
//        int howManyEntries = howManyEntriesScanner.nextInt();

        int howManyEntries = 2;
        ReadJsonFile aaa = new ReadJsonFile();
        int[] bbb = aaa.randomNumbers(howManyEntries);
        User[] ccc = aaa.userData(howManyEntries, bbb);
        for (int i = 0; i < howManyEntries ; i++) {
            System.out.println(bbb[i] + " " + ccc[i]);
        }
        System.out.println(ccc[1].getEmail());

//        int[] randomEntry = new int[howManyEntries];
//        for (int i = 0; i < howManyEntries ; i++) {
//            randomEntry[i] = (int) Math.round(Math.random()*100-1);
//            System.out.print(randomEntry[i] + " ");
//        }
//        System.out.println();
//
//        User[] user = new User[howManyEntries];
//        try {
//            InputStream is = new FileInputStream("registration-data-file.json");
//            JsonReader jsonReader = Json.createReader(is);
//            JsonObject jsonObject = jsonReader.readObject();
//            JsonArray results = jsonObject.getJsonArray("data");
//
//
//        ////0 - firstname, 1 - lastname, 2 - country, 3 - stateProvince, 4 - email  5 - pass
//
//            int i = 0;
//            while(i < howManyEntries) {
//                String singleUser = results.get(randomEntry[i]).toString();
//                String singleUserPureData = singleUser.replaceAll("[\\[\\]{}()\"]", "");
//                String[] userData = singleUserPureData.split(",");
//
//                user[i] = new User(
//                        new Name(userData[0], userData[1]),
//                        new Address(userData[2], userData[3]),
//                        userData[4],
//                        userData[5]);
//                i++;
//            }
//
//        } catch (FileNotFoundException e) {
//            System.out.println("brak pliku");
//        } catch (JsonException w) {
//            System.out.println(w.getMessage());
//        }
//
//        for (User randomUserList : user) {
//            System.out.println(randomUserList.toString());
//        }
//

    }
}
